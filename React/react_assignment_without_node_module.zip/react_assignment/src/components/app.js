import React, {Component} from 'react'; 
import Container from 'react-bootstrap/Container'; 
import Row from 'react-bootstrap/Row'; 
import Col from 'react-bootstrap/Col'; 
import Button from 'react-bootstrap/Button'; 
import InputGroup from 'react-bootstrap/InputGroup'; 
import FormControl from 'react-bootstrap/FormControl'; 
import ListGroup from 'react-bootstrap/ListGroup'; 


class App extends Component { 
constructor(props) { 
	super(props); 

	this.state = { 
	userInput : "", 
	list:[] 
	} 
} 

updateInput(value){ 
	this.setState({ 
	userInput: value, 
	}); 
} 

addItem(){ 
	if(this.state.userInput !== '' ){ 
	const userInput = { 

		id : Math.random(), 
		value : this.state.userInput 
	}; 

	const list = [...this.state.list]; 
	list.push(userInput); 

	this.setState({ 
		list, 
		userInput:""
	}); 
	} 
} 

deleteItem(key){ 
	const list = [...this.state.list]; 

	const updateList = list.filter(item => item.id !== key); 
 
	this.setState({ 
	list:updateList, 
	}); 

} 

render(){ 
	return(<Container> 

		<Row style={{ 
				display: "flex", 
				justifyContent: "center", 
                textAlign: 'center', 
				fontSize: '3rem', 
                fontWeight: 'bolder',
                backgroundColor: 'blue',
				}} 
				>List 
		</Row> 
        
            

		<hr/> 
		<Row> 
		<Col md={{ span: 0, offset: 0 }}> 

		<InputGroup className="">
        
		<FormControl 
			placeholder="Add todo"
			size=""
			value = {this.state.userInput} 
			onChange = {item => this.updateInput(item.target.value)} 
		/> 
		<InputGroup.Append> 
			<Button 
			variant="success"
			size=""
			onClick = {()=>this.addItem()} 
			> 
			ADD 
			</Button> 
		</InputGroup.Append> 
		</InputGroup> 

	</Col> 
</Row> 
		
		{this.state.list.map(item => {return( 

			<ListGroup.Item variant="success" action 
			onClick = { () => this.deleteItem(item.id) }> 
			{item.value} 
			</ListGroup.Item> 

		)})} 
		
	</Container> 
	); 
} 
} 

export default App; 
